# PhotoMorph CaseVault V1

A starter web app for authorized case/evidence management for suspected image-morphing cases.

**Scope and safety:** This is a web app, not an APK. It has no hidden payloads, covert tracking, automatic contact spreading, or non-consensual capture. Use only evidence you are authorized to handle. This starter has no authentication and must not be exposed publicly or used with real sensitive evidence until access control, encryption, retention, backups, and security review are implemented.

## Features
- Case create/list/detail
- Evidence upload with SHA-256 hash
- Custody events and audit log
- JSON case report
- SQLite default database
- Automated tests and GitHub Actions

## Run (Python 3.11+)
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements-dev.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000/docs

## Test
```bash
pytest -q
```

## Push to GitHub
Create an empty GitHub repository, then:
```bash
git init
git add .
git commit -m "Initial PhotoMorph CaseVault"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```
GitHub Actions runs tests on pushes and pull requests. This repository does **not** build an APK; an Android client/wrapper is a separate project.
