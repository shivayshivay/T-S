import hashlib, io, os
from pathlib import Path
os.environ["CASEVAULT_DATA_DIR"] = str(Path(__file__).parent / ".testdata")
from fastapi.testclient import TestClient
from app.main import app
client = TestClient(app)
def test_health():
    r = client.get("/health")
    assert r.status_code == 200 and r.json()["status"] == "ok"
def test_case_duplicate_and_report():
    p = {"title":"Synthetic case", "reference":"TEST-001", "summary":"test only", "actor":"tester"}
    r = client.post("/api/v1/cases", json=p)
    assert r.status_code == 201, r.text
    cid = r.json()["id"]
    assert client.post("/api/v1/cases", json=p).status_code == 409
    assert client.get(f"/api/v1/cases/{cid}/report").json()["case"]["reference"] == "TEST-001"
def test_upload_hash_and_custody():
    p = {"title":"Upload test", "reference":"TEST-002", "summary":"", "actor":"tester"}
    cid = client.post("/api/v1/cases", json=p).json()["id"]
    body = b"synthetic evidence"
    r = client.post(f"/api/v1/cases/{cid}/evidence?actor=tester", files={"file":("sample.txt", io.BytesIO(body), "text/plain")})
    assert r.status_code == 201, r.text
    assert r.json()["sha256"] == hashlib.sha256(body).hexdigest()
    assert any(x["event_type"] == "EVIDENCE_UPLOADED" for x in client.get(f"/api/v1/cases/{cid}/custody").json())
def test_missing_case():
    assert client.get("/api/v1/cases/not-found").status_code == 404
