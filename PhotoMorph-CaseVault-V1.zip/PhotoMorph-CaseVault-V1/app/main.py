import hashlib, os, uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Generator
from fastapi import FastAPI, Depends, File, HTTPException, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Text, Integer, DateTime, ForeignKey, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, Session, sessionmaker

DATA = Path(os.getenv("CASEVAULT_DATA_DIR", "./casevault_data")).resolve()
FILES = DATA / "evidence"
DATA.mkdir(parents=True, exist_ok=True); FILES.mkdir(parents=True, exist_ok=True)
URL = os.getenv("CASEVAULT_DATABASE_URL", f"sqlite:///{DATA / 'casevault.sqlite3'}")
engine = create_engine(URL, connect_args={"check_same_thread": False} if URL.startswith("sqlite") else {})
SessionLocal = sessionmaker(bind=engine, expire_on_commit=False)
def now(): return datetime.now(timezone.utc)

class Base(DeclarativeBase): pass
class Case(Base):
    __tablename__ = "cases"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title: Mapped[str] = mapped_column(String(200))
    reference: Mapped[str] = mapped_column(String(100), unique=True, index=True)
    summary: Mapped[str] = mapped_column(Text, default="")
    status: Mapped[str] = mapped_column(String(20), default="OPEN")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    evidence: Mapped[list["Evidence"]] = relationship(back_populates="case")
class Evidence(Base):
    __tablename__ = "evidence"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id: Mapped[str] = mapped_column(ForeignKey("cases.id"), index=True)
    filename: Mapped[str] = mapped_column(String(255))
    stored_name: Mapped[str] = mapped_column(String(255), unique=True)
    content_type: Mapped[str] = mapped_column(String(150))
    size: Mapped[int] = mapped_column(Integer)
    sha256: Mapped[str] = mapped_column(String(64), index=True)
    actor: Mapped[str] = mapped_column(String(120))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
    case: Mapped[Case] = relationship(back_populates="evidence")
class Event(Base):
    __tablename__ = "custody_events"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    case_id: Mapped[str] = mapped_column(ForeignKey("cases.id"), index=True)
    evidence_id: Mapped[str | None] = mapped_column(String(36), nullable=True)
    event_type: Mapped[str] = mapped_column(String(80))
    actor: Mapped[str] = mapped_column(String(120))
    details: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)
class Audit(Base):
    __tablename__ = "audit_logs"
    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    action: Mapped[str] = mapped_column(String(80))
    actor: Mapped[str] = mapped_column(String(120))
    object_id: Mapped[str] = mapped_column(String(36))
    details: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=now)

Base.metadata.create_all(engine)
app = FastAPI(title="PhotoMorph CaseVault", version="1.0.0")
def dbdep() -> Generator[Session, None, None]:
    db = SessionLocal()
    try: yield db
    finally: db.close()
class CaseIn(BaseModel):
    title: str = Field(min_length=2, max_length=200)
    reference: str = Field(min_length=2, max_length=100, pattern=r"^[A-Za-z0-9._/-]+$")
    summary: str = Field(default="", max_length=5000)
    actor: str = Field(default="demo-user", min_length=2, max_length=120)
def log(db, case_id, action, actor, details="", evidence_id=None):
    db.add(Event(case_id=case_id, event_type=action, actor=actor, details=details, evidence_id=evidence_id))
    db.add(Audit(action=action, actor=actor, object_id=case_id, details=details))
def view(c):
    return {"id": c.id, "title": c.title, "reference": c.reference, "summary": c.summary,
            "status": c.status, "created_at": c.created_at.isoformat(), "evidence_count": len(c.evidence)}
@app.get("/health")
def health(): return {"status": "ok", "app": "PhotoMorph CaseVault", "version": app.version}
@app.post("/api/v1/cases", status_code=201)
def create_case(payload: CaseIn, db: Session = Depends(dbdep)):
    if db.scalar(select(Case).where(Case.reference == payload.reference)):
        raise HTTPException(409, "Case reference already exists")
    c = Case(title=payload.title, reference=payload.reference, summary=payload.summary)
    db.add(c); db.flush(); log(db, c.id, "CASE_CREATED", payload.actor, payload.reference); db.commit(); db.refresh(c)
    return view(c)
@app.get("/api/v1/cases")
def list_cases(db: Session = Depends(dbdep)):
    return [view(c) for c in db.scalars(select(Case).order_by(Case.created_at.desc())).all()]
@app.get("/api/v1/cases/{case_id}")
def get_case(case_id: str, db: Session = Depends(dbdep)):
    c = db.get(Case, case_id)
    if not c: raise HTTPException(404, "Case not found")
    return view(c)
@app.post("/api/v1/cases/{case_id}/evidence", status_code=201)
async def upload(case_id: str, file: UploadFile = File(...), actor: str = "demo-user", db: Session = Depends(dbdep)):
    c = db.get(Case, case_id)
    if not c: raise HTTPException(404, "Case not found")
    if len(actor) < 2 or len(actor) > 120: raise HTTPException(422, "Invalid actor")
    data = await file.read(20 * 1024 * 1024 + 1)
    if not data: raise HTTPException(400, "Empty file")
    if len(data) > 20 * 1024 * 1024: raise HTTPException(413, "File exceeds 20 MiB limit")
    eid = str(uuid.uuid4()); stored = eid + Path(file.filename or "upload.bin").suffix[:12]
    digest = hashlib.sha256(data).hexdigest()
    (FILES / stored).write_bytes(data)
    e = Evidence(case_id=case_id, filename=(file.filename or "upload.bin")[:255], stored_name=stored,
                 content_type=file.content_type or "application/octet-stream", size=len(data), sha256=digest, actor=actor)
    db.add(e); db.flush(); log(db, case_id, "EVIDENCE_UPLOADED", actor, f"sha256={digest}; bytes={len(data)}", e.id); db.commit()
    return {"id": e.id, "case_id": case_id, "filename": e.filename, "size_bytes": e.size, "sha256": e.sha256,
            "content_type": e.content_type, "actor": e.actor, "created_at": e.created_at.isoformat()}
@app.get("/api/v1/cases/{case_id}/evidence")
def list_evidence(case_id: str, db: Session = Depends(dbdep)):
    if not db.get(Case, case_id): raise HTTPException(404, "Case not found")
    rows = db.scalars(select(Evidence).where(Evidence.case_id == case_id)).all()
    return [{"id": e.id, "filename": e.filename, "size_bytes": e.size, "sha256": e.sha256,
             "content_type": e.content_type, "actor": e.actor, "created_at": e.created_at.isoformat()} for e in rows]
@app.get("/api/v1/cases/{case_id}/custody")
def custody(case_id: str, db: Session = Depends(dbdep)):
    if not db.get(Case, case_id): raise HTTPException(404, "Case not found")
    rows = db.scalars(select(Event).where(Event.case_id == case_id).order_by(Event.created_at, Event.id)).all()
    return [{"id": e.id, "evidence_id": e.evidence_id, "event_type": e.event_type, "actor": e.actor,
             "details": e.details, "created_at": e.created_at.isoformat()} for e in rows]
@app.get("/api/v1/cases/{case_id}/report")
def report(case_id: str, db: Session = Depends(dbdep)):
    c = db.get(Case, case_id)
    if not c: raise HTTPException(404, "Case not found")
    ev = db.scalars(select(Evidence).where(Evidence.case_id == case_id)).all()
    events = db.scalars(select(Event).where(Event.case_id == case_id).order_by(Event.created_at, Event.id)).all()
    payload = {"report_type": "PhotoMorph CaseVault report", "generated_at": now().isoformat(),
      "case": {"id": c.id, "title": c.title, "reference": c.reference, "summary": c.summary, "status": c.status},
      "evidence": [{"id": e.id, "filename": e.filename, "size_bytes": e.size, "sha256": e.sha256,
                    "content_type": e.content_type, "actor": e.actor, "created_at": e.created_at.isoformat()} for e in ev],
      "chain_of_custody": [{"id": e.id, "evidence_id": e.evidence_id, "event_type": e.event_type, "actor": e.actor,
                            "details": e.details, "created_at": e.created_at.isoformat()} for e in events],
      "notice": "Starter report; validate chain of custody using organizational procedures."}
    db.add(Audit(action="REPORT_GENERATED", actor="demo-user", object_id=case_id, details="JSON report generated")); db.commit()
    return JSONResponse(payload, headers={"Content-Disposition": f'attachment; filename="case-{c.reference}-report.json"'})
@app.get("/api/v1/audit")
def audit(limit: int = 100, db: Session = Depends(dbdep)):
    limit = max(1, min(limit, 500))
    rows = db.scalars(select(Audit).order_by(Audit.created_at.desc()).limit(limit)).all()
    return [{"id": a.id, "action": a.action, "actor": a.actor, "object_id": a.object_id,
             "details": a.details, "created_at": a.created_at.isoformat()} for a in rows]
